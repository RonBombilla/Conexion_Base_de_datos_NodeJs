CREATE TABLE Estudiantes (
	rut VARCHAR(15) PRIMARY KEY unique not null,
	nombre VARCHAR(100) not null,
	curso VARCHAR (100) not null,
	nivel VARCHAR(2) not null	
);

SELECT * FROM Estudiantes;
