const { Client } = require("pg");
const argumentos = process.argv.slice(2)

const funcion = argumentos[0];
const rut = argumentos[1];
const nombre = argumentos[2];
const curso = argumentos[3];
const nivel = argumentos[4];

//1. Realizar la conexión con PostgreSQL con la clase Client.
const config = {
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "postGRES",
    database: "AlwaysMusic", 
};
const client = new Client(config);


//2. Crear una función asíncrona para registrar un nuevo estudiante en la base de datos.
const nuevoEstudiante = async(rut, nombre, curso, nivel) => {
    const response = await client.query(`INSERT INTO Estudiantes(rut, nombre, curso, nivel) 
                                        VALUES ('${rut}', '${nombre}', '${curso}', '${nivel}') RETURNING *;`);
    console.log(`Estudiante ${response.rows[0].nombre} agregado con éxito`);
}

//3. Crear una función asíncrona para obtener por consola el registro de un estudiante por medio de su rut.
const getEstudiante = async(rut) => {
    const response = await client.query(`SELECT * FROM Estudiantes WHERE rut=${rut} RETURNING *;`)
    console.log(`Registro Actual: ${response.rows[0]}`)
}

//4. Crear una función asíncrona para obtener por consola todos los estudiantes registrados.
const getAllEstudiantes = async() => {
    const response = await client.query(`SELECT * FROM Estudiantes;`)
    const estudiantes = JSON.stringify(response.rows, null, 1)
    console.log(`Registro Actual: ${estudiantes}`)
}

//5. Crear una función asíncrona para actualizar los datos de un estudiante en la base de datos.
const actualizarEstudiante = async(rut, nombre, curso, nivel) => {
    const response = await client.query(`UPDATE Estudiantes SET nombre='${nombre}', curso='${curso}', nivel='${nivel}' WHERE rut='${rut}' RETURNING *;`);
    console.log(`Estudiante ${response.rows[0].nombre} editado con éxito`);
}

//6. Crear una función asíncrona para eliminar el registro de un estudiante de la base de datos.
const borrarEstudiante = async(rut) => {
    const response = await client.query(`DELETE FROM Estudiantes WHERE rut='${rut}' RETURNING *;`)
    console.log(`Registro de Estudiante con rut: ${response.rows[0].rut} eliminado`);
}

const ejecutarFuncion = async()=>{
    client.connect();
    if(funcion == 'nuevoEstudiante'){
        await nuevoEstudiante(rut, nombre, curso, nivel);
    }
    if(funcion == 'getEstudiante'){
        await getEstudiante(rut);
    }
    if(funcion == 'getAllEstudiantes'){
        await getAllEstudiantes();
    }
    if(funcion == 'actualizarEstudiante'){
        await actualizarEstudiante(rut, nombre, curso, nivel);
    }
    if(funcion == 'borrarEstudiante'){
        await borrarEstudiante(rut);
    }
    client.end();
}
ejecutarFuncion();
