const {Pool} = require('pg');

const pool = new Pool({
    host: "localhost",
    port: 5432,
    user: "postgres",
    password: "6651",
    database: "softlife",
});

const createUser = async (datos) => {

    const consulta = {
        text:`INSERT INTO usuarios (email, password ) VALUES ( $1,$2 ) RETURNING *;`,
        values: datos
    }
    try {
        const scriptSql = await pool.query(consulta);
        //console.log(scriptSql.rows[0]);
        return scriptSql;
    } catch (error) {
        console.log(error)
        return error;
    }
};

const getUserData = async (datos) => {
    
    const consulta = {
        text:`SELECT * FROM usuarios WHERE email = $1 AND password = $2;`,
        values: datos,
    }
    
    try {
        console.log(consulta)
        const scriptSql = await pool.query(consulta);
        //console.log(scriptSql.rows);
        return scriptSql.rows[0];
    } catch (error) {
        console.log(error)
        return error;
    }
}

const getUsersData = async () => {
    try {
        const userData = await pool.query(`SELECT * FROM usuarios;`)
        return userData.rows;
    } catch (error) {
        console.log(error);
        return error;        
    }    
}

module.exports = {
    createUser,
    getUserData,
    getUsersData,
};