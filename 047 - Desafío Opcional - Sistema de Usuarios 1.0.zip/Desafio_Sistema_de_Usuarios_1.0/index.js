const http = require('http');
const fs = require('fs');
const {createUser, getUserData, getUsersData} = require('./conection');


http.createServer( async (req, res)=>{
    if (req.url == '/' && req.method === 'GET') {
        res.setHeader('content-type', 'text/html');
        const html = fs.readFileSync('index.html', 'utf8');
        res.end(html);
    }

    if (req.url == '/usuario' && req.method === 'POST') {
        let body = '';
        req.on('data' , (chunk) => {
            body += chunk;
        });
        req.on('end', async () => {
            const datos = Object.values(JSON.parse(body));
            const response = await createUser(datos);
            res.end(JSON.stringify(response));
        })
    }

    if (req.url.startsWith('/login') && req.method === 'POST') {
        let body = '';
        req.on('data', (chunk) => {
            body += chunk;
        });
        req.on('end', async () => {
            const datos = Object.values(JSON.parse(body));
            const result = await getUserData(datos);
            console.log(result);
            if (result) {
                res.end(JSON.stringify(result));
            }else{
                res.statusCode = 401;
                res.end('Feo');
            }  
        })
    }

    if (req.url == '/usuarios' && req.method === 'GET') {
        const result = await getUsersData();
        res.end(JSON.stringify(result));
    }
}).listen(5000, console.log('Server running in http://localhost:5000'));
