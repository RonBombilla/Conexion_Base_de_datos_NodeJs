const { Pool } = require('pg');

const pool = new Pool ({
    host:'localhost',
    port:5432,
    user: 'postgres',
    password: '251095',
    database: 'repertorio'
});

const postDBinsert = async(datos) => {
    const insertado = {
        text: 'INSERT INTO repertorio (cancion, artista, tono) VALUES ($1, $2, $3) RETURNING *;',
        values: datos
    };
    try{
        const result = await pool.query(insertado);
        return result;
    }catch(errorinsert){
        console.log(errorinsert);
        return errorinsert;
    }
}

const getDBconsulta = async() => {
    try{
        const result = await pool.query('SELECT * FROM repertorio');
        return result.rows;
    }catch(errorConsulta){
        console.log(errorConsulta);
        return errorConsulta;
    }
}

const putDBactualizar = async(datos) => {
    const actualizar = {
        text: `UPDATE repertorio SET cancion=$2, artista=$3, tono=$4 WHERE id=$1 RETURNING *;`,
        values: datos
    };
    try{
        const result = await pool.query(actualizar);
        return result.rows[0];
    }catch(errorActualizar){
        console.log(errorActualizar);
        return errorActualizar;
    }
}

const deleteDBeliminar = async(id) => {
    try{
        const result = await pool.query(`DELETE FROM repertorio WHERE id=${id} RETURNING *;`);
        return result.rows[0];
    }catch(errorEliminar){
        console.log(errorEliminar);
        return errorEliminar;
    }
}

module.exports = {
    postDBinsert,
    getDBconsulta,
    putDBactualizar,
    deleteDBeliminar
}