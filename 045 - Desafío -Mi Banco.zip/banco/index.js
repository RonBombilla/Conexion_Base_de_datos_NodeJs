const { Pool } = require('pg');
const Cursor = require("pg-cursor");
const argumentos = process.argv.slice(2);
const funcion = argumentos[0];
const cuenta_1 = argumentos[1];
const cuenta_2 = argumentos[2];
const valor_1 = argumentos[3];
const fecha = argumentos[4];


const pool = new Pool ({
    host : 'localhost',
    port : 5432,
    user : 'postgres',
    password : 'xxxxxxx',
    database : 'xxxxxx'
});

//Crear una función asíncrona que registre una nueva transacción utilizando valores ingresados como 
//argumentos en la línea de comando. Debe mostrar por consola la última transacción realizada.

const pagos = async(client,valor1, cuenta1, cuenta2, hoy) =>{
    try{
        await client.query('BEGIN');
        await client.query(`INSERT INTO transacciones (descripcion, fecha, monto, cuentas)
                        VALUES ('SE HIZO UNA TRANSFERENCIA A ${cuenta2} de ${valor1}',
                                '${hoy}', ${valor1}, ${cuenta1}) RETURNING *;`);
        await client.query(`INSERT INTO transacciones (descripcion, fecha, monto, cuentas)
                        VALUES ('SE RECIBE UNA TRANSFERENCIA DE ${cuenta1} de ${valor1}',
                                '${hoy}', ${valor2}, ${cuenta2}) RETURNING *;`);
        await client.query(`UPDATE cuentas SET saldo = saldo - ${valor1} WHERE id = '${cuenta1}' RETURNING *;`)
        await client.query(`UPDATE cuentas SET saldo = saldo + ${valor1} WHERE id = '${cuenta2}' RETURNING *;`)
        await client.query('COMMIT');
    }catch(e){
        await client.query('ROLLBACK');
        return console.log(e);
    }
}

/*Realizar una función asíncrona que consulte la tabla de transacciones y retorne
máximo 10 registros de una cuenta en específico. Debes usar cursores para esto*/
const consulta_transaccion = async(client,cuenta1) => {
    const consulta = new Cursor(`SELECT * FROM transacciones WHERE cuentas = ${cuenta1}`);
    const cursor = client.query(consulta);
    cursor.read(10, (err, rows)=> {
        if(err) return console.log('el error fue'+ err);
        console.log(rows);
        cursor.close();
    });
}

/*Realizar una función asíncrona que consulte el saldo de una cuenta y que sea
ejecutada con valores ingresados como argumentos en la línea de comando. Debes
usar cursores para esto*/
const cuentas = async(client,cuenta1) => {
    const consulta = new Cursor(`SELECT saldo FROM cuentas WHERE id= ${cuenta1}`);
    const cursor = await client.query(consulta);
    cursor.read(1, (err, rows)=>{
        if(err) return console.log('el error fue '+ err);
        console.log('lo que te queda es ' + rows[0].saldo);
        cursor.close();
    });
}


pool.connect(async(error_db, client) => {
    if(error_db) return console.log(error_db);
    if(funcion == 'pagos'){
        await pagos(client,valor_1, cuenta_1, cuenta_2, fecha)
    }

    if(funcion == 'transacciones'){
        await consulta_transaccion(client,cuenta_1)
    }
    if(funcion == 'saldo'){
        await cuentas(client, cuenta_1);
    }
    pool.end();
});